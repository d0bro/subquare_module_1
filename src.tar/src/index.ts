//Exports all handler functions
export * from './mappings/mappingHandlers'
import "@polkadot/api-augment"
